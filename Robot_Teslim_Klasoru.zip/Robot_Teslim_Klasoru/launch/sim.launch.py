import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource

def generate_launch_description():
    # Robotun durumunu yayınlayan node (Robot State Publisher)
    urdf_file = '/home/ros2_ws/src/description/robot.urdf'
    with open(urdf_file, 'r') as infp:
        robot_desc = infp.read()

    return LaunchDescription([
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{'robot_description': robot_desc}]
        ),
        # Gazebo'yu başlat (Ekran sorunu için şimdilik 'headless' yani arka planda çalışabilir)
        # Ancak biz ekranı zorlayacağız.
    ])
